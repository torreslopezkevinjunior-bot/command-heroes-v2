# Command Heroes 2.0 — Minecraft 26.3 · Forge 66.1.5 · Java 25 · GeckoLib 5.5.7

Tres héroes originales animados con GeckoLib que obedecen una varita:
**Vector** (velocista), **Mugen** (hechicero con Expansión de Dominio) y **Ben** (un único personaje que se transforma en 3 aliens).

## IMPORTANTE: dependencia (GeckoLib)
Este mod **no incluye** GeckoLib dentro del jar. Para jugar necesitas poner **dos** jars en la carpeta `mods`:
1. `commandheroes-2.0.0.jar` (este mod)
2. **GeckoLib 5.5.7 para Forge 26.3** (descárgala de Modrinth o CurseForge)

Sin GeckoLib, Forge mostrará un error de dependencia faltante al iniciar.

## Cómo conseguir el .jar
**Opción A (sin instalar nada):** sube TODO el contenido de esta carpeta (incluida `.github`) a un repositorio de GitHub →
pestaña *Actions* → "Build mod" → descarga el artefacto `commandheroes-jar`.

**Opción B (en tu PC):** Java 25 + Gradle 9.7.1 o superior → `gradle build` → `build/libs/commandheroes-2.0.0.jar`.

## Cómo se juega (pestaña creativa "Héroes a tu Mando")
1. Usa un **Medallón** sobre un bloque para invocar al héroe.
2. **Varita de Mando**:
   - **Agáchate + clic derecho**: cambia la orden seleccionada.
   - **Clic derecho al aire**: envía la orden a todos tus héroes en 64 bloques.
   - **Clic derecho sobre un héroe**: lo reclama (si no tiene dueño) o le manda la orden solo a él.

| Orden | Qué hace |
|---|---|
| Protegerme y combatir | Te siguen y atacan a quien te ataque o a monstruos cercanos |
| Seguirme sin pelear | Te siguen y no atacan |
| Quedarse en su sitio | Se quedan quietos y defienden su zona |
| Duelo: pelear entre ellos | Los héroes en este modo se atacan entre sí |
| Habilidad definitiva | Cada héroe lanza su poder máximo (con recarga) |
| Transformarse (solo Ben) | Ben cambia a la siguiente forma |

## Los héroes
| Héroe | Poderes | Definitiva |
|---|---|---|
| **Vector** | Embestida Relámpago (estela de rayos), Mil Cortes (10 cortes en arco) | Estampida Sónica |
| **Mugen** | Repulsión, Estallido del Vacío, Atracción | **Expansión de Dominio: Vacío Infinito** (cúpula de 12 bloques, 8 s) |
| **Ben** (base) | Golpe Cargado | Máximo Poder: se transforma y lanza la definitiva del alien |
| ↳ **Ignis** (magma) | Bola de Fuego, Nova de Lava | Supernova |
| ↳ **Granito** (roca) | Terremoto, Roca Lanzada | Coloso |
| ↳ **Voltio** (eléctrico) | Rayo en Cadena, Sobrecarga | Tormenta Eléctrica |

**Ben se transforma solo** al pelear: Voltio si el enemigo está lejos, Ignis si hay 3 o más enemigos juntos, Granito cuerpo a cuerpo. La forma dura 60 s o hasta que no haya enemigos; después vuelve a ser Ben. También puedes forzarlo con la orden "Transformarse".

## Archivos de arte (editables en Blockbench con el plugin de GeckoLib)
- Modelos: `assets/commandheroes/geckolib/models/entity/*.geo.json`
- Animaciones: `assets/commandheroes/geckolib/animations/entity/*.animation.json`
- Todo se genera con `tools/generate_assets.py` (requiere Pillow).

## Limitaciones conocidas
- El dueño y la orden **no se guardan** al cerrar el mundo: toca al héroe con la varita para reclamarlo de nuevo.
- Los héroes solo atacan **monstruos** (u otros héroes en Duelo), nunca jugadores ni animales.
- Los efectos visuales usan partículas de vanilla (arcos, anillos, esferas, rayos). Son vistosos, pero no son modelos 3D de efectos.
- Las animaciones son generadas por código: funcionales, pero menos pulidas que las de un animador en Blockbench.

## Si algo falla
Pega el error completo (o `logs/latest.log`) a Claude.
