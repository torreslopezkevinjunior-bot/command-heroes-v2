package com.commandheroes;

import com.commandheroes.entity.HeroNpc;
import com.commandheroes.hero.Kit;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
        DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, CommandHeroes.MODID);

    /** Solo VECTOR, MUGEN y BEN tienen entidad. Las formas de Ben son parte de la entidad BEN. */
    public static final Map<Kit, RegistryObject<EntityType<HeroNpc>>> TYPES = new EnumMap<>(Kit.class);

    static {
        for (Kit kit : Kit.roots()) {
            TYPES.put(kit, ENTITIES.register(kit.id(),
                () -> EntityType.Builder.<HeroNpc>of((type, level) -> new HeroNpc(type, level, kit), MobCategory.CREATURE)
                    .sized(0.6F, 1.95F)
                    .clientTrackingRange(10)
                    .build(ENTITIES.key(kit.id()))
            ));
        }
    }

    private ModEntities() {}
}
