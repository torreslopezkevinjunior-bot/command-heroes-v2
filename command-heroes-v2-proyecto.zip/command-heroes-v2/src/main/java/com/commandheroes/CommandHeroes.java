package com.commandheroes;

import com.commandheroes.client.ClientSetup;
import com.commandheroes.entity.HeroNpc;
import com.commandheroes.hero.Kit;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;

@Mod(CommandHeroes.MODID)
public final class CommandHeroes {
    public static final String MODID = "commandheroes";

    public CommandHeroes(FMLJavaModLoadingContext context) {
        var modBusGroup = context.getModBusGroup();

        ModEntities.ENTITIES.register(modBusGroup);
        ModItems.ITEMS.register(modBusGroup);
        ModTabs.TABS.register(modBusGroup);

        EntityAttributeCreationEvent.BUS.addListener(CommandHeroes::onAttributes);

        // El código de cliente vive aparte para que un servidor dedicado nunca lo cargue.
        if (FMLEnvironment.dist == Dist.CLIENT) {
            ClientSetup.init();
        }
    }

    private static void onAttributes(EntityAttributeCreationEvent event) {
        for (Kit kit : Kit.roots()) {
            event.put(ModEntities.TYPES.get(kit).get(), HeroNpc.createAttributes(kit).build());
        }
    }
}
