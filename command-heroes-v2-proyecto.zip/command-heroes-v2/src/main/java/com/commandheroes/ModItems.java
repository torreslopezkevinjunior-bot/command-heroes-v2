package com.commandheroes;

import com.commandheroes.hero.Kit;
import com.commandheroes.item.CommandWandItem;
import com.commandheroes.item.MedallionItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
        DeferredRegister.create(ForgeRegistries.ITEMS, CommandHeroes.MODID);

    public static final RegistryObject<Item> WAND = ITEMS.register("command_wand",
        () -> new CommandWandItem(new Item.Properties()
            .setId(ITEMS.key("command_wand"))
            .stacksTo(1)
        )
    );

    public static final Map<Kit, RegistryObject<Item>> MEDALLIONS = new EnumMap<>(Kit.class);

    static {
        for (Kit kit : Kit.roots()) {
            String id = "medallion_" + kit.id();
            MEDALLIONS.put(kit, ITEMS.register(id,
                () -> new MedallionItem(new Item.Properties()
                    .setId(ITEMS.key(id))
                    .stacksTo(16),
                    ModEntities.TYPES.get(kit)::get, kit)
            ));
        }
    }

    private ModItems() {}
}
