package com.commandheroes;

import com.commandheroes.hero.Kit;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
        DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CommandHeroes.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
        () -> CreativeModeTab.builder()
            .withTabsBefore(CreativeModeTabs.COMBAT)
            .title(Component.translatable("itemGroup.commandheroes"))
            .icon(() -> ModItems.WAND.get().getDefaultInstance())
            .displayItems((params, output) -> {
                output.accept(ModItems.WAND.get());
                for (Kit kit : Kit.roots()) {
                    output.accept(ModItems.MEDALLIONS.get(kit).get());
                }
            })
            .build()
    );

    private ModTabs() {}
}
