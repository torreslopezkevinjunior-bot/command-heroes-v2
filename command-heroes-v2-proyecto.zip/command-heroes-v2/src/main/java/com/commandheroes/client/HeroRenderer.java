package com.commandheroes.client;

import com.commandheroes.entity.HeroNpc;
import com.geckolib.renderer.GeoEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class HeroRenderer extends GeoEntityRenderer<HeroNpc, LivingEntityRenderState> {
    public HeroRenderer(EntityRendererProvider.Context context) {
        super(context, new HeroGeoModel());
    }
}
