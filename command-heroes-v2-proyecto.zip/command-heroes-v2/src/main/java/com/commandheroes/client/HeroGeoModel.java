package com.commandheroes.client;

import com.commandheroes.CommandHeroes;
import com.commandheroes.entity.HeroNpc;
import com.geckolib.constant.dataticket.DataTicket;
import com.geckolib.model.GeoModel;
import com.geckolib.renderer.base.GeoRenderState;
import net.minecraft.resources.Identifier;

/**
 * Elige modelo y textura según el kit activo (Ben cambia de forma sin cambiar de entidad).
 * Las animaciones son siempre las del héroe base, porque todas las formas comparten esqueleto.
 */
public class HeroGeoModel extends GeoModel<HeroNpc> {
    public static final DataTicket<String> MODEL_ID =
        DataTicket.create("commandheroes_model", String.class);

    private static String modelId(GeoRenderState state) {
        String id = state.getGeckolibData(MODEL_ID);
        return id == null ? "ben" : id;
    }

    @Override
    public Identifier getModelResource(GeoRenderState renderState) {
        return Identifier.fromNamespaceAndPath(CommandHeroes.MODID, "entity/" + modelId(renderState));
    }

    @Override
    public Identifier getTextureResource(GeoRenderState renderState) {
        return Identifier.fromNamespaceAndPath(CommandHeroes.MODID, "textures/entity/" + modelId(renderState) + ".png");
    }

    @Override
    public Identifier getAnimationResource(HeroNpc animatable) {
        return Identifier.fromNamespaceAndPath(CommandHeroes.MODID, "entity/" + animatable.rootKit().id());
    }

    @Override
    public void addAdditionalStateData(HeroNpc animatable, Object relatedObject, GeoRenderState renderState) {
        renderState.addGeckolibData(MODEL_ID, animatable.kit().id());
    }
}
