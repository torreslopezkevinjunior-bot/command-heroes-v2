package com.commandheroes.client;

import com.commandheroes.ModEntities;
import com.commandheroes.hero.Kit;
import net.minecraftforge.client.event.EntityRenderersEvent;

/** Registro solo de cliente. Únicamente se referencia tras comprobar Dist.CLIENT. */
public final class ClientSetup {
    private ClientSetup() {}

    public static void init() {
        EntityRenderersEvent.RegisterRenderers.BUS.addListener(ClientSetup::onRenderers);
    }

    private static void onRenderers(EntityRenderersEvent.RegisterRenderers event) {
        for (Kit kit : Kit.roots()) {
            event.registerEntityRenderer(ModEntities.TYPES.get(kit).get(), HeroRenderer::new);
        }
    }
}
