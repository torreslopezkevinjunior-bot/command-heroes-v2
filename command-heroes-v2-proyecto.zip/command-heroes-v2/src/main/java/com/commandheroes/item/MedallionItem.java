package com.commandheroes.item;

import com.commandheroes.entity.HeroNpc;
import com.commandheroes.hero.Kit;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;

import java.util.function.Supplier;

/** Invoca un héroe al usarlo sobre un bloque. Se consume salvo en creativo. */
public class MedallionItem extends Item {
    private final Supplier<EntityType<HeroNpc>> entityType;
    private final Kit kit;

    public MedallionItem(Properties properties, Supplier<EntityType<HeroNpc>> entityType, Kit kit) {
        super(properties);
        this.entityType = entityType;
        this.kit = kit;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        if (!(context.getLevel() instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }

        BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
        EntityType<HeroNpc> type = entityType.get();
        HeroNpc hero = new HeroNpc(type, serverLevel, kit);
        hero.setPos(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D);
        hero.setCustomName(type.getDescription());
        hero.setCustomNameVisible(true);

        Player player = context.getPlayer();
        if (player != null) {
            hero.claim(player);
        }
        serverLevel.addFreshEntity(hero);

        if (player == null || !player.isCreative()) {
            context.getItemInHand().shrink(1);
        }
        return InteractionResult.SUCCESS;
    }
}
