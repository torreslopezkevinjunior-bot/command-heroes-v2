package com.commandheroes.item;

import com.commandheroes.entity.HeroNpc;
import com.commandheroes.hero.CommandMode;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Varita de mando.
 *  - Agáchate + clic derecho: cambia la orden seleccionada.
 *  - Clic derecho al aire: envía la orden a todos tus héroes en 64 bloques.
 *  - Clic derecho a un héroe: lo reclama (si no tiene dueño) o le envía la orden solo a él.
 */
public class CommandWandItem extends Item {
    private static final Map<UUID, CommandMode> SELECTED = new HashMap<>();

    public CommandWandItem(Properties properties) {
        super(properties);
    }

    public static CommandMode selected(Player player) {
        return SELECTED.getOrDefault(player.getUUID(), CommandMode.PROTECT);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level instanceof ServerLevel serverLevel) {
            if (player.isShiftKeyDown()) {
                CommandMode next = selected(player).next();
                SELECTED.put(player.getUUID(), next);
                player.sendSystemMessage(Component.literal("Orden de la varita: " + next.label()));
            } else {
                CommandMode mode = selected(player);
                int count = 0;
                for (HeroNpc hero : serverLevel.getEntitiesOfClass(HeroNpc.class, player.getBoundingBox().inflate(64.0D))) {
                    if (hero.isOwnedBy(player)) {
                        hero.command(player, mode, serverLevel);
                        count++;
                    }
                }
                player.sendSystemMessage(Component.literal(
                    count == 0 ? "No tienes héroes cerca. Toca uno con la varita para reclamarlo."
                               : mode.label() + " (" + count + " héroes)"));
            }
        }
        return InteractionResult.SUCCESS;
    }
}
