package com.commandheroes.hero;

import net.minecraft.core.particles.ParticleOptions;

/**
 * Descripción de un poder.
 * @param anim    animación GeckoLib que se dispara (debe existir en el archivo de animaciones)
 * @param windup  ticks que pasan entre empezar la animación y aplicar el efecto
 */
public record Ability(
    String name,
    Kind kind,
    int cooldown,
    double minRange,
    double maxRange,
    float damage,
    double radius,
    int stun,
    int burn,
    String anim,
    int windup,
    ParticleOptions particle
) {
    public enum Kind {
        DASH,         // se desplaza como un rayo hasta el objetivo y golpea
        BARRAGE,      // decenas de cortes en un instante
        BURST,        // onda expansiva alrededor del héroe
        GUARD_BURST,  // escudo de absorción + onda expansiva
        PULL,         // atrae enemigos hacia el héroe
        BOLT,         // rayo o proyectil instantáneo a un objetivo
        CHAIN,        // salta entre varios enemigos
        STORM,        // varios rayos sobre enemigos cercanos
        DOMAIN,       // expansión de dominio
        TRANSFORM     // (Ben) se transforma y usa la definitiva del alien
    }
}
