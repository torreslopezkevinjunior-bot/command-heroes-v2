package com.commandheroes.hero;

/** Órdenes que se pueden dar con la varita. */
public enum CommandMode {
    PROTECT("Protegerme y combatir"),
    FOLLOW("Seguirme sin pelear"),
    STAY("Quedarse en su sitio"),
    DUEL("Duelo: pelear entre ellos"),
    ULTIMATE("Habilidad definitiva"),
    TRANSFORM("Transformarse (solo Ben)");

    private final String label;

    CommandMode(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }

    public CommandMode next() {
        CommandMode[] all = values();
        return all[(ordinal() + 1) % all.length];
    }
}
