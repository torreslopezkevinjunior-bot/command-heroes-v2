package com.commandheroes.hero;

import com.commandheroes.hero.Ability.Kind;
import net.minecraft.core.particles.ParticleTypes;

/**
 * Un "kit" es un conjunto de estadísticas, poderes y apariencia.
 * VECTOR, MUGEN y BEN son héroes reales (tienen entidad propia).
 * Los demás son las formas alienígenas de Ben.
 */
public enum Kit {
    VECTOR("vector", "Vector, el Velocista", true, 60.0D, 0.42D, 5.0D, 0.0D, false, true,
        "attack.slash", 4,
        new Ability[] {
            new Ability("Embestida Relámpago", Kind.DASH, 45, 4.0, 20.0, 8.0F, 0.0, 0, 0, "attack.dash", 0, ParticleTypes.ELECTRIC_SPARK),
            new Ability("Mil Cortes", Kind.BARRAGE, 90, 0.0, 4.0, 2.2F, 0.0, 0, 0, "attack.slash", 2, ParticleTypes.CRIT)
        },
        new Ability("Estampida Sónica", Kind.BURST, 600, 0.0, 10.0, 16.0F, 10.0, 0, 0, "attack.powerup", 14, ParticleTypes.ELECTRIC_SPARK)),

    MUGEN("mugen", "Mugen, Hechicero del Vacío", true, 80.0D, 0.30D, 5.0D, 0.0D, false, false,
        "attack.punch", 5,
        new Ability[] {
            new Ability("Repulsión", Kind.BURST, 55, 0.0, 5.0, 4.0F, 5.0, 0, 0, "attack.cast", 6, ParticleTypes.END_ROD),
            new Ability("Estallido del Vacío", Kind.BOLT, 100, 3.0, 15.0, 12.0F, 0.0, 0, 0, "attack.cast", 10, ParticleTypes.PORTAL),
            new Ability("Atracción", Kind.PULL, 160, 5.0, 12.0, 0.0F, 12.0, 0, 0, "attack.cast", 8, ParticleTypes.ENCHANT)
        },
        new Ability("Expansión de Dominio: Vacío Infinito", Kind.DOMAIN, 1200, 0.0, 12.0, 4.0F, 12.0, 0, 0, "attack.powerup", 20, ParticleTypes.PORTAL)),

    BEN("ben", "Ben, el Transformista", true, 90.0D, 0.32D, 5.0D, 0.0D, false, false,
        "attack.punch", 5,
        new Ability[] {
            new Ability("Golpe Cargado", Kind.BURST, 80, 0.0, 3.5, 6.0F, 3.5, 0, 0, "attack.punch", 5, ParticleTypes.CRIT)
        },
        new Ability("Máximo Poder", Kind.TRANSFORM, 0, 0.0, 0.0, 0.0F, 0.0, 0, 0, "attack.powerup", 0, ParticleTypes.END_ROD)),

    // ---- Formas de Ben (no tienen entidad propia) ----
    BEN_IGNIS("ben_ignis", "Ignis, Alienígena de Magma", false, 90.0D, 0.30D, 8.0D, 0.0D, false, false,
        "attack.punch", 5,
        new Ability[] {
            new Ability("Bola de Fuego", Kind.BOLT, 50, 3.0, 16.0, 5.0F, 0.0, 0, 4, "attack.cast", 6, ParticleTypes.FLAME),
            new Ability("Nova de Lava", Kind.BURST, 130, 0.0, 5.0, 7.0F, 5.0, 0, 3, "attack.slam", 12, ParticleTypes.FLAME)
        },
        new Ability("Supernova", Kind.BURST, 700, 0.0, 11.0, 18.0F, 11.0, 0, 5, "attack.powerup", 18, ParticleTypes.LARGE_SMOKE)),

    BEN_GRANITO("ben_granito", "Granito, Alienígena de Roca", false, 90.0D, 0.22D, 11.0D, 0.8D, true, false,
        "attack.slam", 8,
        new Ability[] {
            new Ability("Terremoto", Kind.BURST, 90, 0.0, 6.0, 8.0F, 6.0, 40, 0, "attack.slam", 12, ParticleTypes.CLOUD),
            new Ability("Roca Lanzada", Kind.BOLT, 80, 3.0, 12.0, 9.0F, 0.0, 0, 0, "attack.cast", 8, ParticleTypes.CLOUD)
        },
        new Ability("Coloso", Kind.GUARD_BURST, 700, 0.0, 8.0, 14.0F, 8.0, 60, 0, "attack.slam", 16, ParticleTypes.CLOUD)),

    BEN_VOLTIO("ben_voltio", "Voltio, Alienígena Eléctrico", false, 90.0D, 0.34D, 5.0D, 0.0D, false, false,
        "attack.punch", 4,
        new Ability[] {
            new Ability("Rayo en Cadena", Kind.CHAIN, 70, 0.0, 14.0, 6.0F, 6.0, 0, 0, "attack.cast", 6, ParticleTypes.ELECTRIC_SPARK),
            new Ability("Sobrecarga", Kind.BURST, 120, 0.0, 6.0, 6.0F, 6.0, 30, 0, "attack.powerup", 12, ParticleTypes.ELECTRIC_SPARK)
        },
        new Ability("Tormenta Eléctrica", Kind.STORM, 700, 0.0, 14.0, 10.0F, 14.0, 0, 0, "attack.powerup", 16, ParticleTypes.ELECTRIC_SPARK));

    /** Formas alienígenas de Ben, en el orden del índice de forma (1, 2, 3). */
    public static final Kit[] BEN_FORMS = { BEN_IGNIS, BEN_GRANITO, BEN_VOLTIO };

    private final String id;
    private final String displayName;
    private final boolean root;
    private final double health;
    private final double speed;
    private final double damage;
    private final double knockbackResist;
    private final boolean heavy;
    private final boolean runs;
    private final String meleeAnim;
    private final int meleeWindup;
    private final Ability[] abilities;
    private final Ability ultimate;

    Kit(String id, String displayName, boolean root, double health, double speed, double damage,
        double knockbackResist, boolean heavy, boolean runs, String meleeAnim, int meleeWindup,
        Ability[] abilities, Ability ultimate) {
        this.id = id;
        this.displayName = displayName;
        this.root = root;
        this.health = health;
        this.speed = speed;
        this.damage = damage;
        this.knockbackResist = knockbackResist;
        this.heavy = heavy;
        this.runs = runs;
        this.meleeAnim = meleeAnim;
        this.meleeWindup = meleeWindup;
        this.abilities = abilities;
        this.ultimate = ultimate;
    }

    public String id() { return id; }
    public String displayName() { return displayName; }
    public boolean root() { return root; }
    public double health() { return health; }
    public double speed() { return speed; }
    public double damage() { return damage; }
    public double knockbackResist() { return knockbackResist; }
    public boolean heavy() { return heavy; }
    public boolean runs() { return runs; }
    public String meleeAnim() { return meleeAnim; }
    public int meleeWindup() { return meleeWindup; }
    public Ability[] abilities() { return abilities; }
    public Ability ultimate() { return ultimate; }

    /** Los tres héroes con entidad propia. */
    public static Kit[] roots() {
        return new Kit[] { VECTOR, MUGEN, BEN };
    }
}
