package com.commandheroes.entity;

import com.commandheroes.ModItems;
import com.commandheroes.hero.Ability;
import com.commandheroes.hero.CommandMode;
import com.commandheroes.hero.Kit;
import com.commandheroes.item.CommandWandItem;
import com.geckolib.animatable.GeoEntity;
import com.geckolib.animatable.instance.AnimatableInstanceCache;
import com.geckolib.animatable.manager.AnimatableManager;
import com.geckolib.animation.AnimationController;
import com.geckolib.animation.RawAnimation;
import com.geckolib.animation.object.PlayState;
import com.geckolib.constant.DefaultAnimations;
import com.geckolib.util.GeckoLibUtil;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Héroe obediente y animado con GeckoLib.
 *
 * El servidor decide qué pasa (IA, daño, partículas) y dispara la animación con triggerAnim;
 * el efecto se aplica tras "windup" ticks para que coincida con el golpe de la animación.
 *
 * Limitación conocida: el dueño y la orden NO se guardan al cerrar el mundo.
 * Tras volver a entrar, toca al héroe con la varita para reclamarlo de nuevo.
 */
public class HeroNpc extends PathfinderMob implements GeoEntity {
    private static final EntityDataAccessor<Integer> FORM =
        SynchedEntityData.defineId(HeroNpc.class, EntityDataSerializers.INT);

    private static final double MELEE_REACH = 2.8D;
    private static final int DOMAIN_DURATION = 160;
    private static final int FORM_DURATION = 1200;

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private final Kit rootKit;
    private UUID ownerId;
    private CommandMode mode = CommandMode.STAY;

    private final int[] cooldowns = new int[3];
    private int ultimateCooldown;
    private int attackCooldown;
    private int domainTicks;
    private Vec3 domainCenter = Vec3.ZERO;
    private LivingEntity foe;

    // Solo Ben
    private int transformCooldown;
    private int formTicks;
    private int noFoeTicks;
    private int transforming;
    private boolean queuedUltimate;

    private final List<Delayed> delayed = new ArrayList<>();
    private final Map<Mob, Integer> stunned = new HashMap<>();

    public HeroNpc(EntityType<? extends HeroNpc> type, Level level, Kit rootKit) {
        super(type, level);
        this.rootKit = rootKit;
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes(Kit kit) {
        return Mob.createMobAttributes()
            .add(Attributes.MAX_HEALTH, kit.health())
            .add(Attributes.MOVEMENT_SPEED, kit.speed())
            .add(Attributes.ATTACK_DAMAGE, kit.damage())
            .add(Attributes.FOLLOW_RANGE, 40.0D)
            .add(Attributes.KNOCKBACK_RESISTANCE, kit.knockbackResist());
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(FORM, 0);
        super.defineSynchedData(builder);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
    }

    // ------------------------------------------------------------------ kit / forma

    public Kit rootKit() {
        return rootKit;
    }

    public int formIndex() {
        return this.entityData.get(FORM);
    }

    /** Kit activo: el del héroe o, si Ben está transformado, el del alien. */
    public Kit kit() {
        int form = formIndex();
        if (rootKit == Kit.BEN && form >= 1 && form <= Kit.BEN_FORMS.length) {
            return Kit.BEN_FORMS[form - 1];
        }
        return rootKit;
    }

    // ------------------------------------------------------------------ GeckoLib

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(
            new AnimationController<HeroNpc>("move", 4, state -> {
                if (state.isMoving()) {
                    return state.setAndContinue(kit().runs() ? DefaultAnimations.RUN : DefaultAnimations.WALK);
                }
                return state.setAndContinue(DefaultAnimations.IDLE);
            }),
            new AnimationController<HeroNpc>("action", 0, state -> PlayState.STOP)
                .triggerableAnim("attack.slash", RawAnimation.begin().thenPlay("attack.slash"))
                .triggerableAnim("attack.punch", RawAnimation.begin().thenPlay("attack.punch"))
                .triggerableAnim("attack.cast", RawAnimation.begin().thenPlay("attack.cast"))
                .triggerableAnim("attack.slam", RawAnimation.begin().thenPlay("attack.slam"))
                .triggerableAnim("attack.powerup", RawAnimation.begin().thenPlay("attack.powerup"))
                .triggerableAnim("attack.dash", RawAnimation.begin().thenPlay("attack.dash"))
                .triggerableAnim("misc.transform", RawAnimation.begin().thenPlay("misc.transform"))
        );
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    // ------------------------------------------------------------------ dueño y órdenes

    public boolean isOwnedBy(Player player) {
        return ownerId != null && ownerId.equals(player.getUUID());
    }

    public boolean hasOwner() {
        return ownerId != null;
    }

    public void claim(Player player) {
        this.ownerId = player.getUUID();
        this.mode = CommandMode.PROTECT;
    }

    /** Ejecuta una orden de la varita. */
    public void command(Player issuer, CommandMode newMode, ServerLevel level) {
        if (newMode == CommandMode.ULTIMATE) {
            if (useUltimate(level)) {
                issuer.sendSystemMessage(Component.literal(
                    kit().displayName() + ": ¡" + kit().ultimate().name() + "!"));
            } else {
                issuer.sendSystemMessage(Component.literal(
                    kit().displayName() + ": definitiva en recarga (" + (ultimateCooldown / 20 + 1) + " s)"));
            }
            return;
        }
        if (newMode == CommandMode.TRANSFORM) {
            if (rootKit == Kit.BEN) {
                startTransform(level, (formIndex() + 1) % (Kit.BEN_FORMS.length + 1), false);
            }
            return;
        }
        this.mode = newMode;
    }

    private boolean useUltimate(ServerLevel level) {
        if (transforming > 0 || domainTicks > 0) {
            return false;
        }
        Ability ultimate = kit().ultimate();

        if (ultimate.kind() == Ability.Kind.TRANSFORM) {
            // Ben base: se convierte en un alien y lanza su definitiva al terminar la transformación.
            int form = foe != null ? chooseForm(level) : getRandom().nextInt(Kit.BEN_FORMS.length) + 1;
            startTransform(level, form, true);
            return true;
        }
        if (ultimateCooldown > 0) {
            return false;
        }
        fire(level, ultimate, foe);
        ultimateCooldown = ultimate.cooldown();
        return true;
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (player.getItemInHand(hand).is(ModItems.WAND.get())) {
            if (this.level() instanceof ServerLevel serverLevel) {
                if (ownerId == null) {
                    claim(player);
                    player.sendSystemMessage(Component.literal(kit().displayName() + " ahora te obedece."));
                } else if (!isOwnedBy(player)) {
                    player.sendSystemMessage(Component.literal("Este héroe sigue a otra persona."));
                } else {
                    CommandMode selected = CommandWandItem.selected(player);
                    command(player, selected, serverLevel);
                    player.sendSystemMessage(Component.literal(kit().displayName() + ": " + selected.label()));
                }
            }
            return InteractionResult.SUCCESS;
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        if (source.getEntity() instanceof Player attacker && isOwnedBy(attacker)) {
            return false; // el dueño nunca lastima a su héroe
        }
        return super.hurtServer(level, source, amount);
    }

    // ------------------------------------------------------------------ tick / IA

    @Override
    public void tick() {
        super.tick();

        if (!(this.level() instanceof ServerLevel server)) {
            return;
        }

        for (int i = 0; i < cooldowns.length; i++) {
            if (cooldowns[i] > 0) cooldowns[i]--;
        }
        if (ultimateCooldown > 0) ultimateCooldown--;
        if (attackCooldown > 0) attackCooldown--;
        if (transformCooldown > 0) transformCooldown--;

        processDelayed();
        processStunned();
        if (domainTicks > 0) {
            tickDomain(server);
        }
        think(server);
    }

    private void think(ServerLevel server) {
        if (transforming > 0) {
            getNavigation().stop();
            return;
        }

        Player owner = ownerId == null ? null : server.getPlayerByUUID(ownerId);
        if (owner != null && !owner.isAlive()) {
            owner = null;
        }

        foe = null;
        switch (mode) {
            case FOLLOW -> followOwner(server, owner);
            case STAY -> {
                getNavigation().stop();
                foe = nearestFoe(server, position(), 8.0D);
                fight(server, false);
            }
            case PROTECT -> {
                foe = protectTarget(server, owner);
                if (foe != null) {
                    fight(server, true);
                } else {
                    followOwner(server, owner);
                }
            }
            case DUEL -> {
                foe = nearestDuelOpponent(server);
                if (foe != null) {
                    fight(server, true);
                } else {
                    followOwner(server, owner);
                }
            }
            case ULTIMATE, TRANSFORM -> mode = CommandMode.PROTECT;
        }

        benLogic(server);
    }

    private void followOwner(ServerLevel server, Player owner) {
        if (owner == null) {
            getNavigation().stop();
            return;
        }
        double d2 = distanceToSqr(owner);
        if (d2 > 28.0D * 28.0D) {
            sphere(server, position().add(0.0D, 1.0D, 0.0D), 1.0D, ParticleTypes.PORTAL, 20);
            setPos(owner.getX() + 1.5D, owner.getY(), owner.getZ());
            getNavigation().stop();
            sphere(server, position().add(0.0D, 1.0D, 0.0D), 1.0D, ParticleTypes.PORTAL, 20);
        } else if (d2 > 36.0D) {
            getNavigation().moveTo(owner, 1.15D);
        } else if (d2 < 9.0D) {
            getNavigation().stop();
        }
    }

    private void fight(ServerLevel server, boolean chase) {
        if (foe == null) {
            return;
        }
        getLookControl().setLookAt(foe, 30.0F, 30.0F);
        double dist = distanceTo(foe);

        if (chase && dist > MELEE_REACH) {
            getNavigation().moveTo(foe, 1.15D);
        }

        Kit kit = kit();
        Ability[] abilities = kit.abilities();
        for (int i = 0; i < abilities.length; i++) {
            Ability a = abilities[i];
            if (cooldowns[i] == 0 && dist >= a.minRange() && dist <= a.maxRange()) {
                fire(server, a, foe);
                cooldowns[i] = a.cooldown();
                return;
            }
        }

        if (dist <= MELEE_REACH && attackCooldown == 0) {
            attackCooldown = 20;
            triggerAnim("action", kit.meleeAnim());
            final LivingEntity victim = foe;
            final float dmg = (float) kit.damage();
            delay(kit.meleeWindup(), () -> {
                if (victim.isAlive() && distanceTo(victim) <= MELEE_REACH + 1.0D) {
                    hit(server, victim, dmg);
                    arc(server, position(), getYRot(), 2.0D, -60.0D, 60.0D, 20.0D, ParticleTypes.SWEEP_ATTACK);
                    sound(server, SoundEvents.PLAYER_ATTACK_STRONG);
                }
            });
        }
    }

    // ------------------------------------------------------------------ Ben: transformaciones

    private void benLogic(ServerLevel server) {
        if (rootKit != Kit.BEN || transforming > 0) {
            return;
        }
        int form = formIndex();
        if (form == 0) {
            if (foe != null && transformCooldown == 0 && mode != CommandMode.FOLLOW) {
                startTransform(server, chooseForm(server), false);
            }
        } else {
            if (formTicks > 0) formTicks--;
            noFoeTicks = foe == null ? noFoeTicks + 1 : 0;
            if (formTicks <= 0 || noFoeTicks > 120) {
                startTransform(server, 0, false);
            }
        }
    }

    private int chooseForm(ServerLevel server) {
        if (foe == null) {
            return 2;
        }
        double dist = distanceTo(foe);
        int crowd = foesAround(server, foe.position(), 6.0D).size();
        if (dist > 10.0D) return 3;   // Voltio: a distancia
        if (crowd >= 3) return 1;     // Ignis: muchos enemigos juntos
        return 2;                     // Granito: cuerpo a cuerpo
    }

    private void startTransform(ServerLevel server, int targetForm, boolean thenUltimate) {
        if (transforming > 0) {
            return;
        }
        transforming = 20;
        transformCooldown = 100;
        queuedUltimate = thenUltimate;
        getNavigation().stop();
        triggerAnim("action", "misc.transform");
        sound(server, SoundEvents.AMETHYST_BLOCK_CHIME);

        Vec3 c = position();
        ring(server, c, 1.2D, ParticleTypes.END_ROD);
        sphere(server, c.add(0.0D, 1.0D, 0.0D), 1.4D, ParticleTypes.ENCHANT, 30);

        delay(14, () -> {
            this.entityData.set(FORM, targetForm);
            this.formTicks = targetForm == 0 ? 0 : FORM_DURATION;
            this.noFoeTicks = 0;
            Arrays.fill(cooldowns, 0);
            Vec3 pos = position();
            sphere(server, pos.add(0.0D, 1.0D, 0.0D), 2.0D, ParticleTypes.END_ROD, 40);
            ring(server, pos, 2.5D, ParticleTypes.END_ROD);
            sound(server, SoundEvents.ENDERMAN_TELEPORT);
            if (targetForm == 2) {
                addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 600, 3));
            }
            if (queuedUltimate) {
                queuedUltimate = false;
                ultimateCooldown = 0;
                useUltimate(server);
            }
        });
        delay(20, () -> this.transforming = 0);
    }

    // ------------------------------------------------------------------ objetivos

    private boolean isFoe(LivingEntity e) {
        if (e == this || !e.isAlive()) {
            return false;
        }
        if (e instanceof Monster) {
            return true;
        }
        return e instanceof HeroNpc other && mode == CommandMode.DUEL && other.mode == CommandMode.DUEL;
    }

    private List<LivingEntity> foesAround(ServerLevel server, Vec3 c, double r) {
        AABB box = new AABB(c.x - r, c.y - r, c.z - r, c.x + r, c.y + r, c.z + r);
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : server.getEntitiesOfClass(LivingEntity.class, box)) {
            if (isFoe(e) && e.position().distanceToSqr(c) <= r * r) {
                out.add(e);
            }
        }
        return out;
    }

    private LivingEntity nearestFoe(ServerLevel server, Vec3 c, double r) {
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : foesAround(server, c, r)) {
            double d = e.position().distanceToSqr(c);
            if (d < bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    private LivingEntity protectTarget(ServerLevel server, Player owner) {
        if (owner != null) {
            LivingEntity attacker = owner.getLastHurtByMob();
            if (attacker != null && isFoe(attacker) && attacker.distanceTo(owner) < 24.0F) {
                return attacker;
            }
            LivingEntity nearOwner = nearestFoe(server, owner.position(), 16.0D);
            if (nearOwner != null) {
                return nearOwner;
            }
        }
        return nearestFoe(server, position(), 10.0D);
    }

    private LivingEntity nearestDuelOpponent(ServerLevel server) {
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : foesAround(server, position(), 40.0D)) {
            if (e instanceof HeroNpc) {
                double d = e.position().distanceToSqr(position());
                if (d < bestDist) {
                    bestDist = d;
                    best = e;
                }
            }
        }
        return best;
    }

    // ------------------------------------------------------------------ utilidades

    private boolean hit(ServerLevel server, LivingEntity victim, float amount) {
        if (victim == this || !victim.isAlive() || victim instanceof Player) {
            return false;
        }
        return victim.hurtServer(server, server.damageSources().generic(), amount);
    }

    private void push(LivingEntity victim, Vec3 from, double strength) {
        Vec3 dir = victim.position().subtract(from);
        Vec3 flat = new Vec3(dir.x, 0.0D, dir.z);
        if (flat.lengthSqr() < 1.0E-4D) {
            flat = new Vec3(1.0D, 0.0D, 0.0D);
        }
        flat = flat.normalize().scale(strength);
        victim.setDeltaMovement(victim.getDeltaMovement().add(flat.x, 0.35D, flat.z));
    }

    private void stun(LivingEntity victim, int ticks) {
        if (ticks > 0 && victim instanceof Mob mob) {
            stunned.merge(mob, ticks, Integer::max);
        }
    }

    private void processStunned() {
        Iterator<Map.Entry<Mob, Integer>> it = stunned.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Mob, Integer> entry = it.next();
            Mob mob = entry.getKey();
            int left = entry.getValue() - 1;
            if (!mob.isAlive() || left <= 0) {
                it.remove();
                continue;
            }
            mob.getNavigation().stop();
            mob.setTarget(null);
            Vec3 v = mob.getDeltaMovement();
            mob.setDeltaMovement(0.0D, v.y, 0.0D);
            entry.setValue(left);
        }
    }

    private void addBurn(LivingEntity victim, int hits) {
        for (int i = 1; i <= hits; i++) {
            final int when = i * 10;
            delay(when, () -> {
                if (victim.isAlive() && this.level() instanceof ServerLevel s) {
                    hit(s, victim, 1.5F);
                    s.sendParticles(ParticleTypes.FLAME, victim.getX(), victim.getY() + 1.0D, victim.getZ(),
                        6, 0.3D, 0.5D, 0.3D, 0.02D);
                }
            });
        }
    }

    // ------------------------------------------------------------------ acciones con retardo

    private static final class Delayed {
        int ticks;
        final Runnable action;

        Delayed(int ticks, Runnable action) {
            this.ticks = ticks;
            this.action = action;
        }
    }

    private void delay(int ticks, Runnable action) {
        if (ticks <= 0) {
            action.run();
        } else {
            delayed.add(new Delayed(ticks, action));
        }
    }

    private void processDelayed() {
        // Copia: una acción puede programar otras acciones.
        List<Delayed> due = new ArrayList<>();
        Iterator<Delayed> it = delayed.iterator();
        while (it.hasNext()) {
            Delayed d = it.next();
            if (--d.ticks <= 0) {
                due.add(d);
                it.remove();
            }
        }
        for (Delayed d : due) {
            d.action.run();
        }
    }

    // ------------------------------------------------------------------ efectos visuales

    private void sound(ServerLevel server, SoundEvent event) {
        server.playSound(null, blockPosition(), event, SoundSource.NEUTRAL, 1.0F, 1.0F);
    }

    private void ring(ServerLevel server, Vec3 c, double radius, ParticleOptions particle) {
        for (int i = 0; i < 36; i++) {
            double ang = Math.PI * 2.0D * i / 36.0D;
            server.sendParticles(particle, c.x + Math.cos(ang) * radius, c.y + 0.3D, c.z + Math.sin(ang) * radius,
                1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
    }

    private void line(ServerLevel server, Vec3 from, Vec3 to, ParticleOptions particle) {
        Vec3 delta = to.subtract(from);
        double len = delta.length();
        if (len < 0.1D) {
            return;
        }
        Vec3 step = delta.normalize().scale(0.5D);
        Vec3 p = from;
        for (double d = 0.0D; d < len; d += 0.5D) {
            server.sendParticles(particle, p.x, p.y, p.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            p = p.add(step);
        }
    }

    /** Arco de partículas delante del héroe: el "corte" de las técnicas. */
    private void arc(ServerLevel server, Vec3 c, double yawDeg, double radius,
                     double fromDeg, double toDeg, double tiltDeg, ParticleOptions particle) {
        int steps = 16;
        for (int i = 0; i <= steps; i++) {
            double a = Math.toRadians(yawDeg + fromDeg + (toDeg - fromDeg) * i / steps);
            double dx = -Math.sin(a);
            double dz = Math.cos(a);
            double dy = Math.sin(Math.toRadians(tiltDeg)) * (i - steps / 2.0D) * 0.15D;
            server.sendParticles(particle, c.x + dx * radius, c.y + 1.2D + dy, c.z + dz * radius,
                1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
    }

    /** Esfera de partículas (distribución en espiral de oro). */
    private void sphere(ServerLevel server, Vec3 c, double radius, ParticleOptions particle, int count) {
        for (int i = 0; i < count; i++) {
            double y = 1.0D - 2.0D * (i + 0.5D) / count;
            double r = Math.sqrt(Math.max(0.0D, 1.0D - y * y));
            double theta = i * 2.399963D;
            server.sendParticles(particle,
                c.x + Math.cos(theta) * r * radius, c.y + y * radius, c.z + Math.sin(theta) * r * radius,
                1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
    }

    // ------------------------------------------------------------------ poderes

    private void fire(ServerLevel server, Ability a, LivingEntity target) {
        triggerAnim("action", a.anim());
        delay(a.windup(), () -> execute(server, a, target));
    }

    private void execute(ServerLevel server, Ability a, LivingEntity target) {
        switch (a.kind()) {
            case DASH -> dash(server, a, target);
            case BARRAGE -> barrage(server, a, target);
            case BURST -> burst(server, a);
            case GUARD_BURST -> {
                addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 400, 4));
                burst(server, a);
            }
            case PULL -> pull(server, a);
            case BOLT -> bolt(server, a, target);
            case CHAIN -> chain(server, a);
            case STORM -> storm(server, a);
            case DOMAIN -> domain(server);
            case TRANSFORM -> { }
        }
    }

    private void dash(ServerLevel server, Ability a, LivingEntity target) {
        if (target == null || !target.isAlive()) return;
        Vec3 from = position();
        Vec3 toTarget = target.position().subtract(from);
        if (toTarget.length() < 1.0D) return;
        Vec3 dest = target.position().subtract(toTarget.normalize().scale(1.6D));

        // Estela de rayo con varias líneas desfasadas
        for (int k = -1; k <= 1; k++) {
            Vec3 off = new Vec3(0.0D, 0.7D + k * 0.5D, 0.0D);
            line(server, from.add(off), dest.add(off), a.particle());
        }
        line(server, from.add(0.0D, 1.0D, 0.0D), dest.add(0.0D, 1.0D, 0.0D), ParticleTypes.END_ROD);
        sphere(server, from.add(0.0D, 1.0D, 0.0D), 1.2D, a.particle(), 25);

        setPos(dest.x, target.getY(), dest.z);
        getNavigation().stop();
        sound(server, SoundEvents.ENDERMAN_TELEPORT);
        hit(server, target, a.damage());
        arc(server, position(), getYRot(), 2.2D, -90.0D, 90.0D, 30.0D, a.particle());
        sphere(server, target.position().add(0.0D, 1.0D, 0.0D), 1.5D, a.particle(), 30);
    }

    private void barrage(ServerLevel server, Ability a, LivingEntity target) {
        if (target == null) return;
        sound(server, SoundEvents.PLAYER_ATTACK_STRONG);
        for (int i = 0; i < 10; i++) {
            final int n = i;
            delay(1 + i * 2, () -> {
                if (!target.isAlive()) return;
                hit(server, target, a.damage());
                Vec3 t = target.position();
                // Cada corte con ángulo distinto
                arc(server, t.subtract(0.0D, 0.0D, 0.0D), 36.0D * n, 1.3D, -80.0D, 80.0D, (n % 2 == 0) ? 40.0D : -40.0D, a.particle());
                arc(server, t, 36.0D * n + 90.0D, 1.8D, -60.0D, 60.0D, 25.0D, ParticleTypes.END_ROD);
                if (n % 3 == 0) sound(server, SoundEvents.PLAYER_ATTACK_STRONG);
            });
        }
    }

    private void burst(ServerLevel server, Ability a) {
        Vec3 c = position();
        sound(server, SoundEvents.ANVIL_USE);
        // Anillos que se expanden en 3 oleadas
        for (int wave = 1; wave <= 3; wave++) {
            final double radius = a.radius() * wave / 3.0D;
            delay((wave - 1) * 3, () -> {
                ring(server, c, radius, a.particle());
                ring(server, c.add(0.0D, 0.5D, 0.0D), radius * 0.8D, ParticleTypes.CLOUD);
            });
        }
        server.sendParticles(a.particle(), c.x, c.y + 1.0D, c.z, 50, a.radius() * 0.4D, 0.7D, a.radius() * 0.4D, 0.15D);

        for (LivingEntity e : foesAround(server, c, a.radius())) {
            hit(server, e, a.damage());
            push(e, c, 0.9D);
            stun(e, a.stun());
            addBurn(e, a.burn());
        }
    }

    private void pull(ServerLevel server, Ability a) {
        Vec3 c = position();
        sound(server, SoundEvents.AMETHYST_BLOCK_CHIME);
        ring(server, c, a.radius(), a.particle());
        ring(server, c, a.radius() * 0.6D, a.particle());
        for (LivingEntity e : foesAround(server, c, a.radius())) {
            Vec3 dir = c.subtract(e.position());
            if (dir.lengthSqr() < 1.0E-4D) continue;
            Vec3 pullVec = dir.normalize().scale(0.9D);
            e.setDeltaMovement(pullVec.x, 0.25D, pullVec.z);
            line(server, e.position().add(0.0D, 1.0D, 0.0D), c.add(0.0D, 1.0D, 0.0D), a.particle());
        }
    }

    private void bolt(ServerLevel server, Ability a, LivingEntity target) {
        if (target == null || !target.isAlive()) return;
        Vec3 from = getEyePosition();
        Vec3 to = target.getEyePosition();
        // Haz grueso: tres líneas paralelas
        for (int k = -1; k <= 1; k++) {
            Vec3 off = new Vec3(0.0D, k * 0.15D, 0.0D);
            line(server, from.add(off), to.add(off), a.particle());
        }
        line(server, from, to, ParticleTypes.END_ROD);
        sphere(server, to, 1.4D, a.particle(), 30);
        sound(server, SoundEvents.ENDERMAN_TELEPORT);
        hit(server, target, a.damage());
        addBurn(target, a.burn());
    }

    private void chain(ServerLevel server, Ability a) {
        List<LivingEntity> candidates = foesAround(server, position(), a.maxRange());
        Set<LivingEntity> visited = new HashSet<>();
        Vec3 prev = getEyePosition();
        for (int hop = 0; hop < 4; hop++) {
            double limit = hop == 0 ? a.maxRange() : a.radius();
            LivingEntity best = null;
            double bestDist = Double.MAX_VALUE;
            for (LivingEntity e : candidates) {
                if (visited.contains(e) || !e.isAlive()) continue;
                double d = e.getEyePosition().distanceTo(prev);
                if (d <= limit && d < bestDist) {
                    bestDist = d;
                    best = e;
                }
            }
            if (best == null) break;
            visited.add(best);
            line(server, prev, best.getEyePosition(), a.particle());
            sphere(server, best.getEyePosition(), 1.0D, a.particle(), 12);
            hit(server, best, a.damage());
            prev = best.getEyePosition();
        }
        sound(server, SoundEvents.LIGHTNING_BOLT_THUNDER);
    }

    private void storm(ServerLevel server, Ability a) {
        List<LivingEntity> foes = foesAround(server, position(), a.radius());
        ring(server, position(), a.radius(), a.particle());
        ring(server, position(), a.radius() * 0.5D, a.particle());
        if (foes.isEmpty()) return;
        for (int i = 0; i < 6; i++) {
            final LivingEntity victim = foes.get(i % foes.size());
            delay(5 + i * 7, () -> {
                if (!victim.isAlive()) return;
                Vec3 p = victim.position();
                line(server, new Vec3(p.x, p.y + 10.0D, p.z), p, a.particle());
                line(server, new Vec3(p.x, p.y + 10.0D, p.z), p, ParticleTypes.END_ROD);
                sphere(server, p.add(0.0D, 1.0D, 0.0D), 1.5D, a.particle(), 25);
                sound(server, SoundEvents.LIGHTNING_BOLT_THUNDER);
                hit(server, victim, a.damage());
            });
        }
    }

    // ---- Expansión de Dominio

    private void domain(ServerLevel server) {
        domainTicks = DOMAIN_DURATION;
        domainCenter = position();
        getNavigation().stop();
        sound(server, SoundEvents.ENDERMAN_SCREAM);
        sound(server, SoundEvents.LIGHTNING_BOLT_THUNDER);
        sphere(server, domainCenter.add(0.0D, 1.0D, 0.0D), 2.0D, ParticleTypes.END_ROD, 40);
    }

    private void tickDomain(ServerLevel server) {
        Ability a = kit().ultimate();
        int elapsed = DOMAIN_DURATION - domainTicks;
        double r = Math.min(a.radius(), elapsed * 0.7D + 1.0D);
        Vec3 center = domainCenter.add(0.0D, 1.0D, 0.0D);

        if (domainTicks % 2 == 0) {
            // Cúpula que se expande, con anillos en el suelo y vórtice interior
            sphere(server, center, r, ParticleTypes.PORTAL, 45);
            sphere(server, center, r * 0.96D, ParticleTypes.END_ROD, 8);
            ring(server, domainCenter, r, ParticleTypes.PORTAL);
            ring(server, domainCenter, r * 0.6D, ParticleTypes.ENCHANT);
            server.sendParticles(ParticleTypes.LARGE_SMOKE, center.x, center.y, center.z, 6,
                r * 0.4D, 1.2D, r * 0.4D, 0.02D);
        }

        for (LivingEntity e : foesAround(server, domainCenter, a.radius())) {
            stun(e, 3);
            if (domainTicks % 20 == 0) {
                hit(server, e, a.damage());
                sphere(server, e.position().add(0.0D, 1.0D, 0.0D), 1.2D, ParticleTypes.PORTAL, 20);
            }
        }

        domainTicks--;
        if (domainTicks == 0) {
            sphere(server, center, a.radius(), ParticleTypes.END_ROD, 80);
            ring(server, domainCenter, a.radius(), ParticleTypes.END_ROD);
            sound(server, SoundEvents.AMETHYST_BLOCK_CHIME);
        }
    }

    // ------------------------------------------------------------------ sonidos

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return kit().heavy() ? SoundEvents.IRON_GOLEM_HURT : SoundEvents.PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return kit().heavy() ? SoundEvents.IRON_GOLEM_DEATH : SoundEvents.PLAYER_DEATH;
    }
}
