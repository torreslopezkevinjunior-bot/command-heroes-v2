#!/usr/bin/env python3
"""Genera modelos GeckoLib (.geo.json), animaciones (.animation.json), texturas, items y lang de Command Heroes.
Ejecutar desde la raíz del proyecto:  python3 tools/generate_assets.py   (requiere Pillow)
Los modelos/animaciones se pueden abrir y retocar en Blockbench (plugin GeckoLib)."""
import json, math, os, random
from PIL import Image

random.seed(11)
RES = "src/main/resources/assets/commandheroes"
GEO = f"{RES}/geckolib/models/entity"
ANI = f"{RES}/geckolib/animations/entity"
TEX = f"{RES}/textures"
for d in (GEO, ANI, f"{TEX}/entity", f"{TEX}/item", f"{RES}/items", f"{RES}/models/item", f"{RES}/lang"):
    os.makedirs(d, exist_ok=True)

def dump(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=1, ensure_ascii=False)

# ============================================================ MODELOS
def cube(origin, size, uv, inflate=None):
    c = {"origin": origin, "size": size, "uv": uv}
    if inflate: c["inflate"] = inflate
    return c

def humanoid(arm_size=(4, 12, 4), infl=None, extras=None):
    """Esqueleto humanoide estándar (mismo en todas las formas para compartir animaciones)."""
    infl = infl or {}
    aw = arm_size[0]
    bones = [
        {"name": "root", "pivot": [0, 0, 0]},
        {"name": "body", "parent": "root", "pivot": [0, 24, 0],
         "cubes": [cube([-4, 12, -2], [8, 12, 4], [16, 16], infl.get("body"))]},
        {"name": "head", "parent": "body", "pivot": [0, 24, 0],
         "cubes": [cube([-4, 24, -4], [8, 8, 8], [0, 0], infl.get("head"))]},
        {"name": "rightArm", "parent": "body", "pivot": [-5, 22, 0],
         "cubes": [cube([-4 - aw, 12, -aw / 2], [aw, 12, aw], [40, 16], infl.get("arm"))]},
        {"name": "leftArm", "parent": "body", "pivot": [5, 22, 0],
         "cubes": [cube([4, 12, -aw / 2], [aw, 12, aw], [32, 48], infl.get("arm"))]},
        {"name": "rightLeg", "parent": "root", "pivot": [-1.9, 12, 0],
         "cubes": [cube([-3.9, 0, -2], [4, 12, 4], [0, 16], infl.get("leg"))]},
        {"name": "leftLeg", "parent": "root", "pivot": [1.9, 12, 0],
         "cubes": [cube([-0.1, 0, -2], [4, 12, 4], [16, 48], infl.get("leg"))]},
    ]
    for e in (extras or []):
        bones.append(e)
    return bones

def geo(name, bones):
    return {
        "format_version": "1.12.0",
        "minecraft:geometry": [{
            "description": {
                "identifier": f"geometry.commandheroes.{name}",
                "texture_width": 64, "texture_height": 64,
                "visible_bounds_width": 6, "visible_bounds_height": 5,
                "visible_bounds_offset": [0, 1, 0]},
            "bones": bones}]}

SLOT_A, SLOT_B, SLOT_C = [0, 32], [32, 32], [32, 0]   # zonas libres de la textura para piezas extra

MODELS = {
    # Vector: capa + alas de rayo en la cabeza
    "vector": humanoid(extras=[
        {"name": "cape", "parent": "body", "pivot": [0, 24, 2],
         "cubes": [cube([-4, 10, 2], [8, 14, 1], SLOT_A)]},
        {"name": "wingR", "parent": "head", "pivot": [-4, 28, 0],
         "cubes": [cube([-6, 28, -1.5], [2, 4, 3], SLOT_B)]},
        {"name": "wingL", "parent": "head", "pivot": [4, 28, 0],
         "cubes": [cube([4, 28, -1.5], [2, 4, 3], SLOT_B)]},
    ]),
    # Mugen: abrigo largo + cabello alborotado
    "mugen": humanoid(extras=[
        {"name": "coat", "parent": "body", "pivot": [0, 12, 0],
         "cubes": [cube([-4.5, 2, -2.5], [9, 10, 5], SLOT_A)]},
        {"name": "hair", "parent": "head", "pivot": [0, 32, 0],
         "cubes": [cube([-4, 32, -4], [8, 3, 8], SLOT_B)]},
    ]),
    # Ben: dispositivo en la muñeca
    "ben": humanoid(extras=[
        {"name": "device", "parent": "leftArm", "pivot": [6, 14, 0],
         "cubes": [cube([3.5, 12.5, -2.5], [5, 3, 5], SLOT_A)]},
    ]),
    # Ignis: corona de llamas y hombreras
    "ben_ignis": humanoid(infl={"body": 0.6, "arm": 0.4}, extras=[
        {"name": "crown", "parent": "head", "pivot": [0, 32, 0],
         "cubes": [cube([-3, 32, -3], [6, 6, 6], SLOT_B)]},
        {"name": "padR", "parent": "rightArm", "pivot": [-6, 24, 0],
         "cubes": [cube([-9, 23, -3], [6, 3, 6], SLOT_A)]},
        {"name": "padL", "parent": "leftArm", "pivot": [6, 24, 0],
         "cubes": [cube([3, 23, -3], [6, 3, 6], SLOT_A)]},
    ]),
    # Granito: corpulento, con rocas en los hombros y púas en la espalda
    "ben_granito": humanoid(infl={"body": 1.0, "arm": 1.3, "leg": 0.8, "head": 0.4}, extras=[
        {"name": "rockR", "parent": "rightArm", "pivot": [-6, 24, 0],
         "cubes": [cube([-10.5, 22, -3.5], [7, 5, 7], SLOT_A)]},
        {"name": "rockL", "parent": "leftArm", "pivot": [6, 24, 0],
         "cubes": [cube([3.5, 22, -3.5], [7, 5, 7], SLOT_A)]},
        {"name": "spikes", "parent": "body", "pivot": [0, 18, 2],
         "cubes": [cube([-4, 14, 2.5], [8, 6, 4], SLOT_B)]},
    ]),
    # Voltio: delgado, aletas y bobina en la espalda
    "ben_voltio": humanoid(arm_size=(3, 12, 3), extras=[
        {"name": "finR", "parent": "head", "pivot": [-4, 30, 0],
         "cubes": [cube([-6, 30, -2], [2, 6, 4], SLOT_A)]},
        {"name": "finL", "parent": "head", "pivot": [4, 30, 0],
         "cubes": [cube([4, 30, -2], [2, 6, 4], SLOT_A)]},
        {"name": "coil", "parent": "body", "pivot": [0, 18, 2],
         "cubes": [cube([-3, 13, 2], [6, 8, 3], SLOT_B)]},
    ]),
}
for n, b in MODELS.items():
    dump(f"{GEO}/{n}.geo.json", geo(n, b))

# ============================================================ ANIMACIONES
def t(x):
    s = f"{x:.3f}".rstrip("0").rstrip(".")
    return s if "." in s else s + ".0"

def keys(times, values):
    return {t(a): [round(float(v), 3) for v in b] for a, b in zip(times, values)}

def sampled(length, n, fn):
    return {t(length * i / n): [round(float(v), 3) for v in fn(length * i / n)] for i in range(n + 1)}

def S(x, length, phase=0.0):
    return math.sin(2 * math.pi * x / length + phase)

def anim(length, loop, bones, **extra):
    a = {"loop": loop, "animation_length": length, "bones": bones}
    a.update(extra)
    return a

def bone(rot=None, pos=None, scale=None):
    d = {}
    if rot is not None: d["rotation"] = rot
    if pos is not None: d["position"] = pos
    if scale is not None: d["scale"] = scale
    return d

def build_animations(extra_idle=None, extra_walk=None, extra_run=None, slash_style="single"):
    A = {}
    # ---------- movimiento
    L = 4.0
    idle = {
        "body": bone(pos=sampled(L, 8, lambda x: (0, 0.25 * S(x, L), 0))),
        "head": bone(rot=sampled(L, 8, lambda x: (2 * S(x, L, 1.0), 0, 0))),
        "rightArm": bone(rot=sampled(L, 8, lambda x: (0, 0, 4 + 2 * S(x, L)))),
        "leftArm": bone(rot=sampled(L, 8, lambda x: (0, 0, -4 - 2 * S(x, L)))),
    }
    if extra_idle: idle.update(extra_idle(L))
    A["misc.idle"] = anim(L, True, idle)

    L = 1.0
    walk = {
        "rightLeg": bone(rot=sampled(L, 8, lambda x: (38 * S(x, L), 0, 0))),
        "leftLeg": bone(rot=sampled(L, 8, lambda x: (-38 * S(x, L), 0, 0))),
        "rightArm": bone(rot=sampled(L, 8, lambda x: (-32 * S(x, L), 0, 3))),
        "leftArm": bone(rot=sampled(L, 8, lambda x: (32 * S(x, L), 0, -3))),
        "body": bone(pos=sampled(L, 8, lambda x: (0, 0.3 * abs(S(x, L)), 0))),
    }
    if extra_walk: walk.update(extra_walk(L))
    A["move.walk"] = anim(L, True, walk)

    L = 0.5
    run = {
        "rightLeg": bone(rot=sampled(L, 8, lambda x: (68 * S(x, L), 0, 0))),
        "leftLeg": bone(rot=sampled(L, 8, lambda x: (-68 * S(x, L), 0, 0))),
        "rightArm": bone(rot=sampled(L, 8, lambda x: (-72 * S(x, L) - 25, 0, 4))),
        "leftArm": bone(rot=sampled(L, 8, lambda x: (72 * S(x, L) - 25, 0, -4))),
        "body": bone(rot=keys([0, 0.5], [(20, 0, 0), (20, 0, 0)]),
                     pos=sampled(L, 8, lambda x: (0, 0.5 * abs(S(x, L)), 0))),
        "head": bone(rot=keys([0, 0.5], [(-12, 0, 0), (-12, 0, 0)])),
    }
    if extra_run: run.update(extra_run(L))
    A["move.run"] = anim(L, True, run)

    # ---------- ataques
    if slash_style == "double":
        ts = [0, 0.08, 0.16, 0.24, 0.32, 0.5]
        A["attack.slash"] = anim(0.5, False, {
            "rightArm": bone(rot=keys(ts, [(0, 0, 0), (-150, 0, -10), (50, 0, 15), (-150, 0, 10), (45, 0, -10), (0, 0, 0)])),
            "leftArm": bone(rot=keys(ts, [(0, 0, 0), (20, 0, 0), (-20, 0, 0), (20, 0, 0), (-20, 0, 0), (0, 0, 0)])),
            "body": bone(rot=keys(ts, [(0, 0, 0), (-5, -35, 0), (15, 40, 0), (-5, -35, 0), (15, 40, 0), (0, 0, 0)])),
            "head": bone(rot=keys(ts, [(0, 0, 0), (0, -15, 0), (0, 20, 0), (0, -15, 0), (0, 20, 0), (0, 0, 0)])),
        })
    else:
        ts = [0, 0.1, 0.22, 0.35, 0.6]
        A["attack.slash"] = anim(0.6, False, {
            "rightArm": bone(rot=keys(ts, [(0, 0, 0), (-150, 0, -10), (50, 0, 15), (30, 0, 0), (0, 0, 0)])),
            "leftArm": bone(rot=keys(ts, [(0, 0, 0), (20, 0, 0), (-20, 0, 0), (0, 0, 0), (0, 0, 0)])),
            "body": bone(rot=keys(ts, [(0, 0, 0), (-5, -35, 0), (15, 40, 0), (8, 20, 0), (0, 0, 0)])),
            "head": bone(rot=keys(ts, [(0, 0, 0), (0, -15, 0), (0, 20, 0), (0, 10, 0), (0, 0, 0)])),
        })

    ts = [0, 0.1, 0.18, 0.28, 0.5]
    A["attack.punch"] = anim(0.5, False, {
        "rightArm": bone(rot=keys(ts, [(0, 0, 0), (-30, 0, 0), (-100, 0, 0), (-80, 0, 0), (0, 0, 0)])),
        "leftArm": bone(rot=keys(ts, [(0, 0, 0), (-70, 0, 0), (-40, 0, 0), (-20, 0, 0), (0, 0, 0)])),
        "body": bone(rot=keys(ts, [(0, 0, 0), (0, 25, 0), (8, -15, 0), (4, -5, 0), (0, 0, 0)])),
    })

    ts = [0, 0.25, 0.5, 0.75, 1.0]
    A["attack.cast"] = anim(1.0, False, {
        "rightArm": bone(rot=keys(ts, [(0, 0, 0), (-100, 0, -15), (-105, 0, -10), (-100, 0, -15), (0, 0, 0)])),
        "leftArm": bone(rot=keys(ts, [(0, 0, 0), (-100, 0, 15), (-105, 0, 10), (-100, 0, 15), (0, 0, 0)])),
        "head": bone(rot=keys(ts, [(0, 0, 0), (-12, 0, 0), (-8, 0, 0), (-12, 0, 0), (0, 0, 0)])),
        "body": bone(rot=keys(ts, [(0, 0, 0), (-6, 0, 0), (-3, 0, 0), (-6, 0, 0), (0, 0, 0)])),
    })

    ts = [0, 0.3, 0.45, 0.55, 1.0]
    A["attack.slam"] = anim(1.0, False, {
        "rightArm": bone(rot=keys(ts, [(0, 0, 0), (-170, 0, 0), (-170, 0, 0), (25, 0, 0), (0, 0, 0)])),
        "leftArm": bone(rot=keys(ts, [(0, 0, 0), (-170, 0, 0), (-170, 0, 0), (25, 0, 0), (0, 0, 0)])),
        "body": bone(rot=keys(ts, [(0, 0, 0), (-12, 0, 0), (-12, 0, 0), (40, 0, 0), (0, 0, 0)])),
        "head": bone(rot=keys(ts, [(0, 0, 0), (-10, 0, 0), (-10, 0, 0), (25, 0, 0), (0, 0, 0)])),
        "rightLeg": bone(rot=keys(ts, [(0, 0, 0), (0, 0, 0), (0, 0, 0), (-20, 0, 0), (0, 0, 0)])),
        "leftLeg": bone(rot=keys(ts, [(0, 0, 0), (0, 0, 0), (0, 0, 0), (20, 0, 0), (0, 0, 0)])),
    })

    L = 1.8
    A["attack.powerup"] = anim(L, False, {
        "rightArm": bone(rot=keys([0, 0.5, 1.2, 1.8], [(0, 0, 0), (-20, 0, -75), (-30, 0, -80), (0, 0, 0)])),
        "leftArm": bone(rot=keys([0, 0.5, 1.2, 1.8], [(0, 0, 0), (-20, 0, 75), (-30, 0, 80), (0, 0, 0)])),
        "head": bone(rot=keys([0, 0.5, 1.2, 1.8], [(0, 0, 0), (-25, 0, 0), (-25, 0, 0), (0, 0, 0)])),
        "body": bone(rot=sampled(L, 18, lambda x: (-12 * math.sin(math.pi * x / L), 0, 2 * math.sin(30 * x) * math.sin(math.pi * x / L))),
                     pos=sampled(L, 18, lambda x: (0, 0.5 * math.sin(math.pi * x / L), 0))),
    })

    ts = [0, 0.1, 0.4, 0.5]
    A["attack.dash"] = anim(0.5, False, {
        "body": bone(rot=keys(ts, [(0, 0, 0), (55, 0, 0), (55, 0, 0), (0, 0, 0)])),
        "rightArm": bone(rot=keys(ts, [(0, 0, 0), (70, 0, 5), (70, 0, 5), (0, 0, 0)])),
        "leftArm": bone(rot=keys(ts, [(0, 0, 0), (70, 0, -5), (70, 0, -5), (0, 0, 0)])),
        "head": bone(rot=keys(ts, [(0, 0, 0), (-30, 0, 0), (-30, 0, 0), (0, 0, 0)])),
        "rightLeg": bone(rot=keys(ts, [(0, 0, 0), (-50, 0, 0), (50, 0, 0), (0, 0, 0)])),
        "leftLeg": bone(rot=keys(ts, [(0, 0, 0), (50, 0, 0), (-50, 0, 0), (0, 0, 0)])),
    })

    L = 1.2
    A["misc.transform"] = anim(L, False, {
        "root": bone(rot=sampled(L, 12, lambda x: (0, 720 * x / L, 0)),
                     scale=keys([0, 0.3, 0.7, 1.2], [(1, 1, 1), (1.25, 1.25, 1.25), (0.8, 0.8, 0.8), (1, 1, 1)])),
        "rightArm": bone(rot=keys([0, 0.3, 0.9, 1.2], [(0, 0, 0), (-10, 0, -70), (-10, 0, -70), (0, 0, 0)])),
        "leftArm": bone(rot=keys([0, 0.3, 0.9, 1.2], [(0, 0, 0), (-10, 0, 70), (-10, 0, 70), (0, 0, 0)])),
    })
    return A

def wrap(a):
    return {"format_version": "1.8.0", "animations": a}

# Vector: capa que ondea; corte doble rápido
dump(f"{ANI}/vector.animation.json", wrap(build_animations(
    extra_idle=lambda L: {"cape": bone(rot=sampled(L, 8, lambda x: (3 + 2 * S(x, L), 0, 0)))},
    extra_walk=lambda L: {"cape": bone(rot=sampled(L, 8, lambda x: (10 + 5 * S(x, L), 0, 0)))},
    extra_run=lambda L: {"cape": bone(rot=sampled(L, 8, lambda x: (38 + 10 * S(x, L), 0, 0)))},
    slash_style="double")))
# Mugen: el abrigo se mece
dump(f"{ANI}/mugen.animation.json", wrap(build_animations(
    extra_idle=lambda L: {"coat": bone(rot=sampled(L, 8, lambda x: (2 * S(x, L), 0, 0)))},
    extra_walk=lambda L: {"coat": bone(rot=sampled(L, 8, lambda x: (10 * abs(S(x, L)), 0, 0)))})))
# Ben: esqueleto base compartido por todas las formas
dump(f"{ANI}/ben.animation.json", wrap(build_animations()))

# ============================================================ TEXTURAS
def clamp(c): return tuple(max(0, min(255, int(v))) for v in c)
def noisy(base, var):
    v = random.randint(-var, var)
    return clamp((base[0] + v, base[1] + v, base[2] + v)) + (255,)

def make_skin(name, body, trim, head, face, eyes, hair, slot_a, slot_b, var=8, detail=None):
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0)); px = img.load()
    def fill(x0, y0, x1, y1, base, v=var):
        for y in range(y0, y1):
            for x in range(x0, x1):
                px[x, y] = noisy(base, v)
    fill(0, 0, 32, 16, hair)                    # cabeza (pelo en lados/arriba/atrás)
    fill(8, 8, 16, 16, face, 4)                 # cara frontal
    for r in [(16, 16, 40, 32), (40, 16, 56, 32), (0, 16, 16, 32), (32, 48, 48, 64), (16, 48, 32, 64)]:
        fill(*r, body)
    for (a, b, c, d) in [(40, 16, 56, 32), (0, 16, 16, 32), (32, 48, 48, 64), (16, 48, 32, 64)]:
        for y in range(b + 3, d, 5):
            for x in range(a, c): px[x, y] = trim + (255,)
    fill(0, 32, 32, 48, slot_a)                 # pieza extra A
    fill(32, 32, 64, 48, slot_b)                # pieza extra B
    for (x, y) in [(9, 11), (10, 11), (13, 11), (14, 11)]: px[x, y] = eyes + (255,)
    for x in range(10, 14): px[x, 14] = (40, 20, 20, 255)
    if detail: detail(px)
    img.save(f"{TEX}/entity/{name}.png")

def vector_detail(px):
    for p in [(24,21),(23,22),(22,23),(23,23),(24,23),(23,24),(22,25),(23,26),(24,27)]:
        px[p] = (255, 255, 255, 255)
    for x in range(8, 16): px[x, 11] = (25, 25, 30, 255)
    for (x, y) in [(9,11),(10,11),(13,11),(14,11)]: px[x, y] = (255, 255, 255, 255)
    for y in range(32, 48):                      # franja clara en la capa
        for x in range(0, 32):
            if (x // 3) % 4 == 0: px[x, y] = (255, 190, 60, 255)

def mugen_detail(px):
    for x in range(8, 16):
        px[x, 11] = (212, 175, 55, 255); px[x, 12] = (212, 175, 55, 255)
    for (x, y) in [(9,12),(10,12),(13,12),(14,12)]: px[x, y] = (90, 240, 255, 255)
    for y in range(20, 32):
        px[23, y] = (212, 175, 55, 255); px[24, y] = (212, 175, 55, 255)
    for x in range(0, 32):                       # ribete dorado del abrigo
        px[x, 32] = (212, 175, 55, 255); px[x, 47] = (212, 175, 55, 255)

def ben_detail(px):
    for y in range(20, 32):                      # franja verde del chaleco
        px[22, y] = (80, 230, 100, 255); px[25, y] = (80, 230, 100, 255)
    for x in range(0, 32):                       # dispositivo: brillo central
        for y in range(32, 48):
            if 8 <= (x % 20) <= 11 and 5 <= (y - 32) <= 7: px[x, y] = (255, 255, 255, 255)
    for (x, y) in [(9,11),(10,11),(13,11),(14,11)]: px[x, y] = (60, 200, 90, 255)

def ignis_detail(px):
    for _ in range(160):
        x, y = random.randrange(64), random.randrange(64)
        if px[x, y][3] == 255: px[x, y] = (255, random.randint(140, 220), 20, 255)
    for (x, y) in [(9,11),(10,11),(13,11),(14,11)]: px[x, y] = (255, 255, 120, 255)

def granito_detail(px):
    for _ in range(120):
        x, y = random.randrange(64), random.randrange(64)
        if px[x, y][3] == 255: px[x, y] = noisy((70, 110, 60), 10)
    for _ in range(80):
        x, y = random.randrange(64), random.randrange(64)
        if px[x, y][3] == 255: px[x, y] = (35, 35, 40, 255)
    for (x, y) in [(9,11),(10,11),(13,11),(14,11)]: px[x, y] = (90, 200, 255, 255)

def voltio_detail(px):
    for (a, b, c, d) in [(40,16,56,32),(0,16,16,32),(32,48,48,64),(16,48,32,64)]:
        for y in range(b, d, 2): px[a + (y % 4), y] = (255, 240, 60, 255)
    for y in range(20, 32, 2): px[22 + (y % 4), y] = (255, 240, 60, 255)
    for (x, y) in [(9,11),(10,11),(13,11),(14,11)]: px[x, y] = (255, 255, 150, 255)

make_skin("vector", (235,190,25), (255,255,255), (235,190,25), (235,190,25), (255,255,255), (235,190,25), (200,45,35), (250,250,250), detail=vector_detail)
make_skin("mugen", (60,25,95), (212,175,55), (150,20,40), (225,180,150), (90,240,255), (150,20,40), (40,15,70), (150,20,40), detail=mugen_detail)
make_skin("ben", (45,45,55), (80,230,100), (110,70,40), (225,185,150), (60,200,90), (110,70,40), (60,60,70), (60,60,70), detail=ben_detail)
make_skin("ben_ignis", (150,35,20), (40,15,10), (170,45,20), (170,45,20), (255,255,120), (255,140,30), (90,30,20), (255,150,30), var=14, detail=ignis_detail)
make_skin("ben_granito", (115,115,122), (80,80,88), (125,125,132), (125,125,132), (90,200,255), (95,95,102), (105,105,112), (70,70,78), var=12, detail=granito_detail)
make_skin("ben_voltio", (70,130,200), (255,240,60), (190,225,250), (190,225,250), (255,255,150), (255,240,60), (255,240,60), (40,70,140), detail=voltio_detail)

# ---------- items
def new16():
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); return im, im.load()
im, p = new16()
for i in range(11): p[3+i, 12-i] = (110,70,35,255); p[4+i, 12-i] = (80,50,25,255)
for (x, y) in [(12,2),(13,2),(12,3),(13,3),(11,2),(12,1),(13,1),(14,2),(12,4)]: p[x, y] = (90,230,255,255)
p[12, 2] = (255,255,255,255)
im.save(f"{TEX}/item/command_wand.png")
for n, c in {"vector": (240,195,30), "mugen": (130,60,200), "ben": (70,210,100)}.items():
    im, p = new16()
    for y in range(16):
        for x in range(16):
            d = ((x - 7.5) ** 2 + (y - 8.5) ** 2) ** 0.5
            if d <= 6.2: p[x, y] = c + (255,)
            if 5.2 < d <= 6.2: p[x, y] = (30, 30, 35, 255)
    for x in range(6, 10): p[x, 1] = (90, 90, 95, 255)
    p[7, 2] = (90, 90, 95, 255); p[8, 2] = (90, 90, 95, 255)
    for (x, y) in [(7,7),(8,7),(7,8),(8,8),(7,9),(8,9)]: p[x, y] = (255, 255, 255, 255)
    im.save(f"{TEX}/item/medallion_{n}.png")

for iid in ["command_wand", "medallion_vector", "medallion_mugen", "medallion_ben"]:
    dump(f"{RES}/models/item/{iid}.json", {"parent": "minecraft:item/generated", "textures": {"layer0": f"commandheroes:item/{iid}"}})
    dump(f"{RES}/items/{iid}.json", {"model": {"type": "minecraft:model", "model": f"commandheroes:item/{iid}"}})

lang = {
    "itemGroup.commandheroes": "Héroes a tu Mando",
    "item.commandheroes.command_wand": "Varita de Mando",
    "item.commandheroes.medallion_vector": "Medallón de Vector",
    "item.commandheroes.medallion_mugen": "Medallón de Mugen",
    "item.commandheroes.medallion_ben": "Medallón de Ben",
    "entity.commandheroes.vector": "Vector, el Velocista",
    "entity.commandheroes.mugen": "Mugen, Hechicero del Vacío",
    "entity.commandheroes.ben": "Ben, el Transformista",
}
dump(f"{RES}/lang/es_es.json", lang)
dump(f"{RES}/lang/en_us.json", lang)
print("assets generados")
